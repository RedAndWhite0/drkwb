<nav class="navbar navbar-default" style="margin-bottom:0px; background-color:#337ab7">
  <div class="container">
    <p class="navbar-text text-white"><strong>DEMO mode is currently active in order to access demo features or contact author click <a href="{{route('demo')}}" class="text-white">here</a></strong></p>
  </div>
</nav>
