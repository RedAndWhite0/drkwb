<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchasesTable extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('purchases', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uniqueid');
            $table->integer('buyer_id')->unsigned();
            $table->integer('seller_id')->unsigned()->nullable();
            $table->integer('product_id')->unsigned();
            $table->unsignedBigInteger('value');
            $table->boolean('delivered')->default(0);
            $table->longtext('goods')->nullable();
            $table->integer('state')->default(0);
            $table->timestamps();

            $table->foreign('buyer_id')->references('id')->on('users');
            $table->foreign('seller_id')->references('id')->on('users');
            $table->foreign('product_id')->references('id')->on('products');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('purchases');
    }
}
